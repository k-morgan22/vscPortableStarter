![Frontend](screenshots/frontend-folder-structure.png)
