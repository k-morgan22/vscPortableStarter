export const environment = {
  production: true,
  apiEndpoint: '/api',
};
