<template>
  <router-view></router-view>
</template>

<script>
  export default {
    name: 'users-view',
  };
</script>
