<template>
  <div class="modal is-active">
    <div class="modal-background"></div>
    <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: 'auth',
  };
</script>
