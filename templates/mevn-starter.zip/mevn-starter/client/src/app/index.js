import { routes as dashboard } from './dashboard';
import { routes as users } from './users';
import { routes as items } from './items';
import { routes as auth } from './auth';

export default [...auth, ...dashboard, ...users, ...items];
